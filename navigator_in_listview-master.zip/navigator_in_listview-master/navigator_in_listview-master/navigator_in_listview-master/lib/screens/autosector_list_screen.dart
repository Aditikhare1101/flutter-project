import 'package:flutter/material.dart';
import 'package:navigator_in_listview/model/autosector.dart';
import 'package:navigator_in_listview/screens/autosector_details_screen.dart';

class autosectorListScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          title: Text('Autosector Emergency Measures'),
        ),
        body: ListView.builder(
            itemCount: autosectorList.length,
            itemBuilder: (context, index) {
              autosector autosector1 = autosectorList[index];
              return Card(
                child: ListTile(
                  title: Text(autosector1.title),
                  leading: Image.network(autosector1.imageUrl),
                  trailing: Icon(Icons.arrow_forward_rounded),
                  onTap: () {
                    Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (context) => autosectorDetailsScreen(autosector1)));
                  }),);}));}}
