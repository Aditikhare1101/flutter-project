package com.example.navigator_in_listview

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
